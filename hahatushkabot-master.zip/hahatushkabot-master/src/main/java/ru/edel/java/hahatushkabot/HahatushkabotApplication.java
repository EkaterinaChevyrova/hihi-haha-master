package ru.edel.java.hahatushkabot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HahatushkabotApplication {

	public static void main(String[] args) {
		SpringApplication.run(HahatushkabotApplication.class, args);
	}

}
