package ru.edel.java.hahatushkabot.repository;

import ru.edel.java.hahatushkabot.model.Visitors;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VisitorsRepository extends JpaRepository<Visitors, Long>{
}
