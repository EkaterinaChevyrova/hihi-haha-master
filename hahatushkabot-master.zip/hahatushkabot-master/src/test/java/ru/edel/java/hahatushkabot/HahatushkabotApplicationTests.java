package ru.edel.java.hahatushkabot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HahatushkabotApplicationTests {

	@Test
	void contextLoads() {
	}

}
